﻿namespace AssestManagement.Models
{
    public class Tenant
    {
        public int TenantId { get; set; }
        public string TenantCode { get; set; }
        public string TenantName { get; set; }
        public string ConnectionString { get; set; }
    }
}
