﻿using AssestManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace AssestManagement.Data
{
    public class TenantDbContext : DbContext
    {
        public TenantDbContext(DbContextOptions<TenantDbContext> options) : base(options)
        {
        }

        public DbSet<Tenant> Tenants { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tenant>().ToTable("Tenants");
            base.OnModelCreating(modelBuilder);
        }
    }

}
